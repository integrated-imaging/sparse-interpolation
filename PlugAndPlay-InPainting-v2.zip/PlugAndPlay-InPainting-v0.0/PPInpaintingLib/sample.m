function sampledImg = sample(img, mask)

sampledImg = img.*mask;

end