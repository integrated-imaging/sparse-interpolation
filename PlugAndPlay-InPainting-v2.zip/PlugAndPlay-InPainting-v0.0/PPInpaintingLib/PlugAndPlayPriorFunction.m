function map_image = PlugAndPlayPriorFunction(output_folder_name, params, options, InitialEst, mask, sampledImg, imageName, imageExt)

% Plug and Play priors script file
% To solve (1/2)||y-Ax||_{D}^2+ beta*prior(x)
% lambda - lagrange multiplier
% beta - regularization
% u - augmented lagrangian vector nx X ny (Object size)
% v - temporary image used in AL method nx X ny

[h, w] = size(sampledImg);
Amatrix = generateAmatrix(mask, 0);

ScaleMax = 255; % Dynamic range of input data
params.threshold = 1e-3;% Stopping criteria for algorithm

%% Other paramters - ICD

params.num_iter = 1; % Number of ICD inner loops per ADMM iteration
params.u = zeros(h, w); % Augmented Lagrange vector
params.v = zeros(h, w); % Auxilary variable
params.verbose = 1;

%% Denoising parameter (std. dev) for ALL algorithms
kparams.sigma = sqrt(params.beta/params.lambda);

%% Denoising parameters - BM3D
if strcmp(options.prior, 'BM3D')
    kparams.blocksize = 2;
    kparams.dictsize = 512;
    kparams.maxval= ScaleMax;
    kparams.trainnum = 3600;
    kparams.iternum = 10;
    kparams.memusage = 'high';
end

%% Augmented Lagrangian Iterations

params.v = InitialEst; % Initialization for inpainting

[map_image, params, ~] = ADMM_Core(InitialEst, sampledImg, Amatrix, params, kparams, options, imageName, imageExt);

clear out_file_name;

out_file_name = sprintf('%d_%s.png', round(params.sampling*100), options.prior);
out_file_name = strcat(output_folder_name, out_file_name);
imwrite(uint8(map_image), out_file_name);

