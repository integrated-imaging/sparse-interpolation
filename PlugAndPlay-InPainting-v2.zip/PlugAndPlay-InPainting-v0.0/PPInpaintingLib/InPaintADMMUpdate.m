function [map_image, e]=InPaintADMMUpdate(map_image,Mask, e, var_w, params)
%Function that performs random order ICD with a quadratic penalty
%on the input (for Augmented lagrangian)
%Inputs map_image : initial value of image to be reconstructed
%           Mask  : Binary Mask of coordinate where measurements are done
%               e : current error image
%           var_w : white noise variance for deblurring
%           params: hold the parameter for Augmented Lagrangian variables
% Outputs  map_image : Final reconstruction
%                  e : Updated error image

TempK = params.v - params.u;

[m, n]=size(map_image);

for row = 1:m
    for col=1:n
        
        v=map_image(row, col);
        
        if(Mask(row, col) == 1)
            update = (var_w*params.lambda*TempK(row, col)+(e(row, col) + map_image(row, col)))/(1 + var_w*params.lambda);
        else
            update = TempK(row, col);
        end
        if(update > 0)
            map_image(row, col)=update;
        else
            map_image(row, col)=0;
        end
        
        %Update the relevant error image entries
         e(row, col)=e(row, col) - (map_image(row, col)-v);
    end
end