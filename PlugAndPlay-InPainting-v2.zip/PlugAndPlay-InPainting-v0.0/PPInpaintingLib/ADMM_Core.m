function [map_image, params, eps_primal] = ADMM_Core(map_image, sampledImg, Amatrix, params, kparams, options, imageName, imageExt)

%Performs ADMM based minimization of min_{x,v} (1/2)||y-Ax||^2 + s(v)
% Inputs
% map_image is an inital estimate for x
% Amatrix = A stored as a sparse matrix
% params contains parameters associated with the optimization
% kparams contains prior model parameters
% options.prior represents what prior is used in s(v)

iter = 1;

stop_crit = ones(1, params.max_iter);
eps_primal = zeros(1, params.max_iter);
eps_dual = zeros(1, params.max_iter);


%% END OF DEBUG STATEMENTS

statement = sprintf('Inpainting "%s" with %s prior...', [imageName, imageExt], options.prior);

h = waitbar(0, '1', 'Name', statement,...
            'CreateCancelBtn', ...
            'setappdata(gcbf,''canceling'',1)');
setappdata(h, 'canceling', 0)

while (iter < params.max_iter && stop_crit(iter) > params.threshold)
    
    % Check for Cancel button press
    if getappdata(h, 'canceling')
        break
    end
    
    % Report current estimate in the waitbar's message field
    waitbar(iter/params.max_iter, h, sprintf('%d%%', round(100*double(iter)/double(params.max_iter))));
    
    if(iter > 1) %After the first outer iteration just do 1 ICD iteration
        params.num_iter = 1;
    end
    
    map_image = DataTermOptInPaint(map_image, sampledImg, params, Amatrix);
    
    kparams.x = map_image + params.u;
    
    switch(options.prior)
        case 'BM3D'
            [~, imout] = BM3D(1, kparams.x/kparams.maxval, kparams.sigma);
            imout = imout.*kparams.maxval; % For BM3D this is needed       
    end
    
    prev_v = params.v;
    params.v = imout;
    
    params.u = params.u + (map_image - params.v); % update of u
    
    eps_primal(iter) = sum(abs(params.v(:) - map_image(:)))./length(map_image(:)); %sum(abs(map_image(:)));    
    eps_dual(iter) = sum(abs(params.v(:) - prev_v(:)))./length(map_image(:)); %./sum((abs(prev_v(:))));
    stop_crit(iter) = (eps_primal(iter) + eps_dual(iter))/2;
    
    
    %% Code to vary penalty parmeter
    
    if(isfield(params, 'tau') && isfield(params, 'mu'))
        if (eps_primal(iter) > params.mu*eps_dual(iter))
            params.lambda = params.lambda*params.tau;
            params.u = params.u/params.tau;
            display('Adjusting scaling');
        else
            if (eps_dual(iter) > params.mu*eps_primal(iter))
                params.lambda= params.lambda/params.tau;
                params.u=params.u*params.tau;
                display('Adjusting scaling');
            end
        end
    end
    
    %% End of varying penalty parameter segment
    
    iter = iter + 1;
end

delete(h); % DELETE the waitbar; don't try to CLOSE it.

end

