function [new_image] = DataTermOptInPaint(map_image, sampled, params, List)
%Optimizes the function : data mismatch term + augmented vector
% min_x ((1/2)||y-Ax||_D^{2} + lambda ||x-(v-rho)||^2 )

%Compute initial error image

Hx = map_image;
e = zeros(size(sampled));
Mask = zeros(size(sampled));
[ListLen, ~] = size(List);
for i = 1:ListLen
    row = List(i, 1);
    col = List(i, 2);
    e(row, col) = sampled(row, col) - Hx(row, col);
    Mask(row, col) = 1;
end

for k = 1:params.num_iter          
    [map_image, e] = InPaintADMMUpdate(map_image, Mask, e, 0, params);   
end

new_image = map_image;
