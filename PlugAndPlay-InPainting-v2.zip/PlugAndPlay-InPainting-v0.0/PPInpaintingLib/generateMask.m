function mask = generateMask(h, w, samplingPercentage)

% h: height of the mask
% w: width of the mask

mask = ones(h, w);
p_f = samplingPercentage/100;

for row = 1:h
    for col = 1:w
        if (rand > p_f)
            mask(row, col) = 0;
        end
    end 
end

