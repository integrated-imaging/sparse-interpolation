
clear;
close all;
clc;

%% Inputs and Parameters

imageName = 'Federer';
imageExt = '.png';
mask = 'Federer_Mask.mat';

options.prior = 'BM3D';

% Plug-and-Play parameters
params.lambda = 1/20;  % Default: 1/20 (works for most natural images)
params.beta = 1;       % Default: 1 (increase for more prior regularization, decrease for less regularization.)

params.max_iter = 90; % Maximum # of P&P iterations; Default: 100


%% Processing

% Adding folders to our path
addpath(genpath('Denoisers'));
addpath(genpath('Images'));
addpath(genpath('PPInpaintingLib'));
addpath(genpath('Results'));
outputFolder = ['Results/', imageName];
if ~exist(outputFolder)
    mkdir(outputFolder);
end
addpath(outputFolder);

sampledImg = double(imread([imageName, imageExt]));
[h, w] = size(sampledImg);
load Federer_mask;

params.sampling = nnz(mask)/(h*w);

InitialEst = shepard_initialize(sampledImg, mask, 4/((params.sampling)^0.5), 2);

inpaintedImg = PlugAndPlayPriorFunction(['Results/', imageName, '/'], params, options, InitialEst, mask, sampledImg, imageName, imageExt);


%% Display

figure
subplot(1, 2, 1)
imshow(sampledImg, []);
title('Sampled image');

subplot(1, 2, 2)
imshow(inpaintedImg, []);
title('Inpainted image');

