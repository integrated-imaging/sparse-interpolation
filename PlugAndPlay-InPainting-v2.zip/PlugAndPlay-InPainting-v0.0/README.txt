README
_______________________________________________________________

Plug-and-Play Inpainting Software, Version 0.0, July 06, 2016.

Suhas Sreehari and Prof. Charles A. Bouman.
Purdue University, School of Electrical and Computer Engineering.

Collaborators:
S. V. Venkatakrishnan (Lawrence Berkeley National Lab), Brendt Wohlberg (Los Alamos National Lab), Lawrence F. Drummy (AFRL), Jeffrey P. Simmons (AFRL), and Prof. Gregery T. Buzzard (Purdue University, Mathematics Department).

_______________________________________________________________

1. Purpose

This software inpaints (or interpolates) a 2D grayscale image from a set of pixel samples.


2. About the software

This software is based on the research carried out by Suhas Sreehari, S V. Venkatakrishnan, and Prof. Charles A. Bouman at Purdue University. 
This implements the plug-and-play algorithm for the problem of 2D image inpainting, using denoising operators as prior models.

This version supports BM3D [1] as the prior model.


3. Running the software

Step 1: Move the directory (“PlugAndPlay-InPainting-v0.0”) to your MATLAB directory.
Step 2: Navigate to the “PlugAndPlay-InPainting-v0.0” directory on MATLAB.
Step 3: Run DEMO.m

Note: The directory “PPInpaintingLib” contains all the functions needed for inpainting.


4. Usage

Please cite our work if you use this software for your paper.

Our paper: S. Sreehari et al., “Plug-and-play priors for bright field electron tomography and sparse interpolation,” arXiv preprint arXiv:1512.07331, 2016.

BibTex entry:

@article{sreehari2015plug,
  title={Plug-and-play priors for bright field electron tomography and sparse interpolation},
  author={Sreehari, Suhas and Venkatakrishnan, SV and Wohlberg, Brendt and Drummy, Lawrence F and Simmons, Jeffrey P and Bouman, Charles A},
  journal={arXiv preprint arXiv:1512.07331},
  year={2015}
}


5. References

[1] K. Dabov et al., “Image denoising by sparse 3-D transform-domain collaborative filtering,” IEEE Transactions on Image processing, Vol. 16, No. 8, pp. 2080-2095, 2007.

